package com.eddd.qatar2022;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private final int totalFiguritas = 646;
    private int cantidadFiguritas = 0;
    DecimalFormat formatNumber = new DecimalFormat("#.00");

    // Inicio
    private RelativeLayout fwc00, fwc01, fwc02, fwc03, fwc04, fwc05, fwc06, fwc07;
    private TextView cant_fwc00, cant_fwc01, cant_fwc02, cant_fwc03, cant_fwc04, cant_fwc05, cant_fwc06, cant_fwc07;
    private int n_fwc00, n_fwc01, n_fwc02, n_fwc03, n_fwc04, n_fwc05, n_fwc06,  n_fwc07;
    private TextView fwc00_text, fwc01_text, fwc02_text, fwc03_text, fwc04_text, fwc05_text, fwc06_text, fwc07_text;

    // Estadios
    private RelativeLayout fwc08, fwc09, fwc10, fwc11, fwc12, fwc13, fwc14, fwc15, fwc16, fwc17;
    private TextView cant_fwc08, cant_fwc09, cant_fwc10, cant_fwc11, cant_fwc12, cant_fwc13, cant_fwc14, cant_fwc15, cant_fwc16, cant_fwc17;
    private int n_fwc08, n_fwc09, n_fwc10, n_fwc11, n_fwc12, n_fwc13, n_fwc14,  n_fwc15, n_fwc16, n_fwc17;
    private TextView fwc08_text, fwc09_text, fwc10_text, fwc11_text, fwc12_text, fwc13_text, fwc14_text, fwc15_text, fwc16_text, fwc17_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);


        // Inicio
        fwc00 = findViewById(R.id.fwc00);
        fwc01 = findViewById(R.id.fwc01);
        fwc02 = findViewById(R.id.fwc02);
        fwc03 = findViewById(R.id.fwc03);
        fwc04 = findViewById(R.id.fwc04);
        fwc05 = findViewById(R.id.fwc05);
        fwc06 = findViewById(R.id.fwc06);
        fwc07 = findViewById(R.id.fwc07);

        cant_fwc00 = findViewById(R.id.cant_fwc00);
        cant_fwc01 = findViewById(R.id.cant_fwc01);
        cant_fwc02 = findViewById(R.id.cant_fwc02);
        cant_fwc03 = findViewById(R.id.cant_fwc03);
        cant_fwc04 = findViewById(R.id.cant_fwc04);
        cant_fwc05 = findViewById(R.id.cant_fwc05);
        cant_fwc06 = findViewById(R.id.cant_fwc06);
        cant_fwc07 = findViewById(R.id.cant_fwc07);

        fwc00_text = findViewById(R.id.fwc00_text);
        fwc01_text = findViewById(R.id.fwc01_text);
        fwc02_text = findViewById(R.id.fwc02_text);
        fwc03_text = findViewById(R.id.fwc03_text);
        fwc04_text = findViewById(R.id.fwc04_text);
        fwc05_text = findViewById(R.id.fwc05_text);
        fwc06_text = findViewById(R.id.fwc06_text);
        fwc07_text = findViewById(R.id.fwc07_text);

        // Estadios
        fwc08 = findViewById(R.id.fwc08);
        fwc09 = findViewById(R.id.fwc09);
        fwc10 = findViewById(R.id.fwc10);
        fwc11 = findViewById(R.id.fwc11);
        fwc12 = findViewById(R.id.fwc12);
        fwc13 = findViewById(R.id.fwc13);
        fwc14 = findViewById(R.id.fwc14);
        fwc15 = findViewById(R.id.fwc15);
        fwc16 = findViewById(R.id.fwc16);
        fwc17 = findViewById(R.id.fwc17);

        cant_fwc08 = findViewById(R.id.cant_fwc08);
        cant_fwc09 = findViewById(R.id.cant_fwc09);
        cant_fwc10 = findViewById(R.id.cant_fwc10);
        cant_fwc11 = findViewById(R.id.cant_fwc11);
        cant_fwc12 = findViewById(R.id.cant_fwc12);
        cant_fwc13 = findViewById(R.id.cant_fwc13);
        cant_fwc14 = findViewById(R.id.cant_fwc14);
        cant_fwc15 = findViewById(R.id.cant_fwc15);
        cant_fwc16 = findViewById(R.id.cant_fwc16);
        cant_fwc17 = findViewById(R.id.cant_fwc17);

        fwc08_text = findViewById(R.id.fwc08_text);
        fwc09_text = findViewById(R.id.fwc09_text);
        fwc10_text = findViewById(R.id.fwc10_text);
        fwc11_text = findViewById(R.id.fwc11_text);
        fwc12_text = findViewById(R.id.fwc12_text);
        fwc13_text = findViewById(R.id.fwc13_text);
        fwc14_text = findViewById(R.id.fwc14_text);
        fwc15_text = findViewById(R.id.fwc15_text);
        fwc16_text = findViewById(R.id.fwc16_text);
        fwc17_text = findViewById(R.id.fwc17_text);

        sumCards();
        subtractCards();

    }

    private void sumCards(){

        fwc00.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc00 += 1;
                cant_fwc00.setText(String.valueOf(n_fwc00));
                fwc00.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc00.setTextColor(getResources().getColor(R.color.white_gray));
                fwc00_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc00 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc01 += 1;
                cant_fwc01.setText(String.valueOf(n_fwc01));
                fwc01.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc01.setTextColor(getResources().getColor(R.color.white_gray));
                fwc01_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc01 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc02 += 1;
                cant_fwc02.setText(String.valueOf(n_fwc02));
                fwc02.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc02.setTextColor(getResources().getColor(R.color.white_gray));
                fwc02_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc02 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc03 += 1;
                cant_fwc03.setText(String.valueOf(n_fwc03));
                fwc03.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc03.setTextColor(getResources().getColor(R.color.white_gray));
                fwc03_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc03 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc04 += 1;
                cant_fwc04.setText(String.valueOf(n_fwc04));
                fwc04.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc04.setTextColor(getResources().getColor(R.color.white_gray));
                fwc04_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc04 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc05 += 1;
                cant_fwc05.setText(String.valueOf(n_fwc05));
                fwc05.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc05.setTextColor(getResources().getColor(R.color.white_gray));
                fwc05_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc05 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc06.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc06 += 1;
                cant_fwc06.setText(String.valueOf(n_fwc06));
                fwc06.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc06.setTextColor(getResources().getColor(R.color.white_gray));
                fwc06_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc06 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc07.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc07 += 1;
                cant_fwc07.setText(String.valueOf(n_fwc07));
                fwc07.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc07.setTextColor(getResources().getColor(R.color.white_gray));
                fwc07_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc07 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc08.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc08 += 1;
                cant_fwc08.setText(String.valueOf(n_fwc08));
                fwc08.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc08.setTextColor(getResources().getColor(R.color.white_gray));
                fwc08_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc08 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc09.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc09 += 1;
                cant_fwc09.setText(String.valueOf(n_fwc09));
                fwc09.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc09.setTextColor(getResources().getColor(R.color.white_gray));
                fwc09_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc09 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc10 += 1;
                cant_fwc10.setText(String.valueOf(n_fwc10));
                fwc10.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc10.setTextColor(getResources().getColor(R.color.white_gray));
                fwc10_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc10 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc11 += 1;
                cant_fwc11.setText(String.valueOf(n_fwc11));
                fwc11.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc11.setTextColor(getResources().getColor(R.color.white_gray));
                fwc11_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc11 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc12 += 1;
                cant_fwc12.setText(String.valueOf(n_fwc12));
                fwc12.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc12.setTextColor(getResources().getColor(R.color.white_gray));
                fwc12_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc12 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc13 += 1;
                cant_fwc13.setText(String.valueOf(n_fwc13));
                fwc13.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc13.setTextColor(getResources().getColor(R.color.white_gray));
                fwc13_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc13 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc14 += 1;
                cant_fwc14.setText(String.valueOf(n_fwc14));
                fwc14.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc14.setTextColor(getResources().getColor(R.color.white_gray));
                fwc14_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc14 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc15 += 1;
                cant_fwc15.setText(String.valueOf(n_fwc15));
                fwc15.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc15.setTextColor(getResources().getColor(R.color.white_gray));
                fwc15_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc15 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc16 += 1;
                cant_fwc16.setText(String.valueOf(n_fwc16));
                fwc16.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc16.setTextColor(getResources().getColor(R.color.white_gray));
                fwc16_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc16 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

        fwc17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n_fwc17 += 1;
                cant_fwc17.setText(String.valueOf(n_fwc17));
                fwc17.setBackground(getResources().getDrawable(R.drawable.custom_shape_onclicked));
                cant_fwc17.setTextColor(getResources().getColor(R.color.white_gray));
                fwc17_text.setTextColor(getResources().getColor(R.color.white_gray));

                if(n_fwc17 == 1){
                    cantidadFiguritas += 1;
                }
            }
        });

    }

    private void subtractCards(){

        fwc00.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if(n_fwc00 > 0){
                    n_fwc00 -= 1;
                }
                if(n_fwc00 == 0){
                    fwc00.setBackground(getResources().getDrawable(R.drawable.custom_shape));
                    cant_fwc00.setTextColor(getResources().getColor(R.color.white));
                    fwc00_text.setTextColor(getResources().getColor(R.color.white));
                }
                cant_fwc00.setText(String.valueOf(n_fwc00));
                return true;
            }
        });

    }

}